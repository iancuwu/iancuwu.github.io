#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <unistd.h>

using namespace std;
int A[101][101],T[101][101],n,m;
int i,j,k;
ifstream fin("fisier.txt");

void mesaj_final(){
    cout<<endl<<"---------------------------------";
    cout<<endl<<"Operatiune incheiata cu succes."
    <<endl<<"Se intoarce la meniu in 2 secunde..."<<endl<<endl;
    sleep(2);
}
void citire_drum(int &x, int &y){
            cout << "Te rog sa introduci punctul in care te afli: ";
            cin>>x;
            cout << "Te rog sa introduci destinatia: ";
            cin>>y;
}
void citire(){
    int x,y,cost;
    fin>>n>>m;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++) {
            A[i][j]=100;
            if(i==j)
                A[i][j] = 0;
        }
    for(i=1;i<=m;i++) {
        fin>>x>>y>>cost;
        A[x][y]=cost;
        T[x][y]=x;
    }
}

void afisare_matrice(){
    cout<<"MATRICEA COSTURILOR"<<endl<<"---------------------------------"<<endl<<endl;
    for(i=1;i<=n;i++) {
        for(j=1;j<=n;j++){
            if(A[i][j]==100)cout<<setw(3)<<"X"<<' ';
            else cout<<setw(3)<<A[i][j]<<" ";
        }
        cout<<endl;
    }
    mesaj_final();
}

void Roy_Floyd(){
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(A[i][j]>A[i][k]+A[k][j]) {
                    A[i][j]=A[i][k]+A[k][j];
                    T[i][j]=T[k][j];
                }
}

void drum(int i,int j){
    if(j!=0) {
        drum(i,T[i][j]);
        cout<<j<<" ";
    }
}
int costDrum(int i, int j){
    int sum=0;
    while(j!=0) {
        sum+=A[T[i][j]][j];
        j=T[i][j];
    }
    if(sum==0) return 0;
    return sum;
}
int timpNecesar(int x,int y){
    float costTotal;
    costTotal= costDrum(x,y);
    if(costTotal==0)return 0;
    return round(costTotal*1000/833.33);
}

int main() {
    int op,cost;
    int x, y;
    citire();
    Roy_Floyd();
    do {
        cout << "Meniu" << endl <<"----------------------------------" <<endl;
        cout << "1. Afisare matrice de cost minim"<<endl;
        cout << "2. Drumul cu costul cel mai mic dintre doua puncte" << endl;
        cout << "3. Distanta de la un punct la altul (cost)"<<endl;
        cout << "4. Timpul necesar parcurgerii drumului de la doua puncte alese" << endl;
        cout << "0. Iesire" << endl;
        cout <<"----------------------------------" <<endl;
        cout << "Alege o optiune: ";
       
        cin >> op;
        switch (op) {
            case 1:
                afisare_matrice();
                break;
            case 2:
                citire_drum(x,y);
                cout << "Drumul de cost minim de la "<<x << " la " << y << " este: ";
                drum(x, y);
                mesaj_final();
                break;
            case 3:
                citire_drum(x,y);
                cost=costDrum(x,y);
                if(cost!=0) cout << "Distanta de parcurs (costul) este: " << cost << " Km";
                else cout<<"Nu exista drumul specificat! Alegeti alte puncte.";
                mesaj_final();
                break;
            case 4:
                citire_drum(x,y);
                cost=costDrum(x,y);
                if(cost!=0) cout << "Timpul minim necesar este: " << cost<< " minute";
                else cout<<"Nu exista drumul specificat! Alegeti alte puncte.";
                mesaj_final();
                break;
            case 0:
                cout << "Iesire din program." << endl;
                break;
            default:
                cout << "Optiune invalida! Te rog sa alegi din nou." << endl;
                cout<<endl;
                sleep(2);
        }
    } while (op != 0);
    return 0;
}